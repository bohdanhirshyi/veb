$(document).ready(function(){
    $('.header-burger').click(function(event){
        $('.heade-burger,.menu').toggleClass('active');
    });
});
